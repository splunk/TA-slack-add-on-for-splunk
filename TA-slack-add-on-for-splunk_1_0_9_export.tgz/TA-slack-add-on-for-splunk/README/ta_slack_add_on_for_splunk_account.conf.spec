[<name>]
password = 